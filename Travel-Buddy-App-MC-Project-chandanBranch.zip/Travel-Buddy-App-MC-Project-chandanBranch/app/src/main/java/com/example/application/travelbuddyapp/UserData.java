package com.example.application.travelbuddyapp;

public class UserData {
    String signupType, username, email;

    public UserData(String signupType, String username, String email)
    {
        this.signupType = signupType;
        this.username = username;
        this.email = email;
    }

}
