package com.example.application.travelbuddyapp;

import android.support.v4.app.Fragment;

public interface ToAndFro {
    public void ChangeFragment(Fragment toChange);
}
